import json
import os

import boto3
import spotipy
from spotipy.cache_handler import CacheHandler
from spotipy.exceptions import SpotifyException
from spotipy.oauth2 import SpotifyOAuth
from datetime import datetime

# ============================================================
# AWS Secrets Manager
# ============================================================

secrets_manager = boto3.client("secretsmanager")
SECRET_ID = os.environ["SPOTIFY_SECRET_ID"]
SCOPE = "playlist-read-private playlist-read-collaborative"
REDIRECT_URI = "http://127.0.0.1:8888/callback"


# ============================================================
# Secrets Manager helpers
# ============================================================

def load_secret():
    response = secrets_manager.get_secret_value(
        SecretId=SECRET_ID
    )
    return json.loads(response["SecretString"])


class SecretsManagerCacheHandler(CacheHandler):

    def get_cached_token(self):
        """
        Spotipy calls this when it needs the cached OAuth token.
        """
        config = load_secret()
        token_info = config.get("token_info")
        if not token_info:
            raise RuntimeError(
                "token_info not found in Secrets Manager"
            )
        return token_info

    def save_token_to_cache(self, token_info):
        """
        Spotipy calls this when a refreshed token needs to be saved.
        """
        config = load_secret()
        config["token_info"] = token_info
        secrets_manager.update_secret(
            SecretId=SECRET_ID,
            SecretString=json.dumps(config)
        )
        print("Spotify token updated in Secrets Manager")


# ============================================================
# Spotify client
# ============================================================

def get_spotify():
    config = load_secret()
    if "client_id" not in config:
        raise RuntimeError("client_id missing from Secrets Manager")

    if "client_secret" not in config:
        raise RuntimeError("client_secret missing from Secrets Manager")

    if "token_info" not in config:
        raise RuntimeError("token_info missing from Secrets Manager")

    auth_manager = SpotifyOAuth(
        client_id=config["client_id"],
        client_secret=config["client_secret"],
        redirect_uri=REDIRECT_URI,
        scope=SCOPE,
        cache_handler=SecretsManagerCacheHandler(),
        open_browser=False,
    )
    return spotipy.Spotify(auth_manager=auth_manager)


# ============================================================
# Lambda handler
# ============================================================

def lambda_handler(event, context):
    try:
        # ----------------------------------------------------
        # Get playlist ID from Lambda event
        # ----------------------------------------------------
        playlist_id = "5Sy0vFMwVBfbw8dIez7oIV"   #event.get("playlist_id")
        if not playlist_id:
            return {
                "statusCode": 400,
                "body": json.dumps({
                    "error": "playlist_id missing in event"
                })
            }
        print("Requested playlist:", playlist_id)

        # ----------------------------------------------------
        # Load token information for diagnostics
        # ----------------------------------------------------

        config = load_secret()
        token_info = config.get("token_info", {})
        token_scope = token_info.get("scope")
        print("Token scopes:", token_scope)

        # ----------------------------------------------------
        # Create Spotify client
        # ----------------------------------------------------

        sp = get_spotify()
        me = sp.current_user()
        user_id = me["id"]
        display_name = me.get("display_name")

        print("Logged in as:", display_name)
        print("Spotify user ID:", user_id)

        items = []
        results = sp.playlist_items(playlist_id, limit=50)
        items.extend(results["items"])

        while results["next"]:
            results = sp.next(results)
            items.extend(results["items"])

        print("Total playlist items fetched:", len(items))

        client = boto3.client('s3')
        filename = "spotify_raw" + str(datetime.now()) + ".json"
        client.put_object(Bucket="spotify-etm-project-tapas", Key="raw_data/to_processed/"+filename, Body=json.dumps(results))

    except SpotifyException as e:

        print("Spotify API error")
        print("HTTP status:", e.http_status)
        print("Spotify error:", str(e))

        return {
            "statusCode": e.http_status or 500,
            "body": json.dumps({
                "error": "Spotify API error",
                "status": e.http_status,
                "message": str(e),
                "playlist_id": event.get(
                    "playlist_id"
                )
            })
        }

    except Exception as e:

        print("Unexpected error:", repr(e))

        return {
            "statusCode": 500,
            "body": json.dumps({
                "error": "Unexpected error",
                "message": str(e)
            })
        }