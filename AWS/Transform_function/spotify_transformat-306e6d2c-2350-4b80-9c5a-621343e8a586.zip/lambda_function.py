import json
import boto3
from io import StringIO
import pandas as pd
from datetime import datetime

def album(data):
    album_list=[]
    for item in data['items']:
        album_id = item['item']['album']['id']
        album_name = item['item']['album']['name']
        album_release_date = item['item']['album']['release_date']
        album_total_tracks = item['item']['album']['total_tracks']
        album_spotify_url = item['item']['external_urls']['spotify']

        album_elements = {
            'album_id': album_id,
            'album_name': album_name,
            'album_release_date': album_release_date,
            'album_total_tracks': album_total_tracks,
            'album_spotify_url': album_spotify_url
        }
    album_list.append(album_elements)
    return album_list

def artist(data):
    artists_list = []
    for row in data['items']:
        for key,value in row.items():
            if key == 'item':
                for artist in value['artists']:
                    artist_dict = {
                        'artist_id': artist['id'],
                        'artist_name': artist['name'],
                        'external_url': artist['href']
                    }
                    artists_list.append(artist_dict)
    return artists_list

def songs(data):
    song_list = []
    for row in data['items']:
        song_id = row['item']['id']
        song_name = row['item']['name']
        song_duration = row['item']['duration_ms']
        song_url = row['item']['external_urls']['spotify']
        song_added_at = row['added_at']
        album_id = row['item']['album']['id']
        artist_id = row['item']['artists'][0]['id']

        song_dict = {
            'song_id': song_id,
            'song_name': song_name,
            'song_duration': song_duration,
            'song_url': song_url,
            'song_added_at': song_added_at,
            'album_id': album_id,
            'artist_id': artist_id
        }
        song_list.append(song_dict)
    return song_list


def lambda_handler(event, context):
    s3 = boto3.client('s3')
    Bucket = "spotify-etm-project-tapas"
    Key = "raw_data/to_processed/"

    spotify_data = []
    spotify_keys = []
    for file in s3.list_objects(Bucket=Bucket, Prefix=Key)['Contents']:
        file_key = file['Key']
        if file_key.split('.')[-1] == 'json':
            response = s3.get_object(Bucket=Bucket, Key=file_key)
            content = response['Body']
            json_object = json.loads(content.read())
            spotify_data.append(json_object)
            spotify_keys.append(file_key)
        
    for data in spotify_data:
        album_list = album(data)
        artist_list = artist(data)
        songs_list = songs(data)
    
        album_df = pd.DataFrame.from_dict(album_list)
        album_df = album_df.drop_duplicates(subset=['album_id'])

        artist_df = pd.DataFrame.from_dict(artist_list)
        artist_df = artist_df.drop_duplicates(subset=['artist_id'])

        #Song DataFrame
        song_df = pd.DataFrame.from_dict(songs_list)

        album_df['album_release_date'] = pd.to_datetime(album_df['album_release_date'])
        song_df['song_added_at'] = pd.to_datetime(song_df['song_added_at'])

        song_file = "transformed_data/songs_data/" + str(datetime.now()) + '.csv'
        song_buffer = StringIO()
        song_df.to_csv(song_buffer, index=False)
        song_content = song_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=song_file, Body=song_content)

        album_file = "transformed_data/album_data/" + str(datetime.now()) + '.csv'
        album_buffer = StringIO()
        album_df.to_csv(album_buffer, index=False)
        album_content = album_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=album_file, Body=album_content)

        artist_file = "transformed_data/artist_data/" + str(datetime.now()) + '.csv'
        artist_buffer = StringIO()
        artist_df.to_csv(artist_buffer, index=False)
        artist_content = artist_buffer.getvalue()
        s3.put_object(Bucket=Bucket, Key=artist_file, Body=artist_content)

    s3_resource = boto3.resource('s3')

    for key in spotify_keys:
        copy_source = {
            'Bucket': Bucket,
            'Key': key
        }
        s3_resource.meta.client.copy(copy_source, Bucket, 'raw_data/processed/' + key.split('/')[-1])
        s3_resource.Object(Bucket, key).delete()